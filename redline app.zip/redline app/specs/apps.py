from django.apps import AppConfig


class SpecsConfig(AppConfig):
    name = 'specs'
